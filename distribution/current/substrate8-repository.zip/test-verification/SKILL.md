---
metadata_schema: team-hub-skill/v1
summary: Requires behavioral, failure-path, and durable-seam evidence for tests and review.
skill_id: test-verification
version: 2.2.0
lifecycle_status: active
family: code-quality
capabilities: []
source_provenance:
  kind: original
  references: []
  note: null
authority_boundary: docs-only
activation_triggers:
- trigger_id: test-writing
  task_kinds:
  - testing
  risk_flags: []
  path_globs: []
  roles: []
  lanes: []
  surfaces:
  - build-review
  - repository
  description: tests are being written
- trigger_id: coverage-review
  task_kinds:
  - review
  - testing
  risk_flags: []
  path_globs: []
  roles: []
  lanes: []
  surfaces:
  - build-review
  - repository
  description: test coverage is reviewed
- trigger_id: behavioral-quality
  task_kinds:
  - testing
  - verification
  risk_flags: []
  path_globs: []
  roles: []
  lanes: []
  surfaces:
  - build-review
  - repository
  description: behavioral test quality is assessed
- trigger_id: high-risk-acceptance
  task_kinds:
  - review
  - testing
  - verification
  risk_flags:
  - high-risk-file
  path_globs: []
  roles: []
  lanes: []
  surfaces:
  - build-review
  - repository
  description: high-risk behavior needs test evidence
activation_exclusions: []
full_load_required_when:
- behavioral-quality
- coverage-review
- high-risk-acceptance
- test-writing
section_references: []
platforms:
- portable
- team-hub-runtime-advisory
surfaces:
- build-review
- repository
required_roles: []
required_lanes: []
related_doctrine:
- docs/architecture/FILE_ARCHITECTURE_AND_MAINTAINABILITY_STANDARD.md
- docs/architecture/HIGH_RISK_FILE_REGISTRY.md
graph_edges:
- type: depends_on
  target: repo-grounding
  condition_trigger_ids: []
- type: related
  target: code-quality
  condition_trigger_ids: []
child_references: []
return_contributions:
- contribution_id: test-verification/test-proof
  activation_trigger_ids:
  - test-writing
  - coverage-review
  - behavioral-quality
  - high-risk-acceptance
  requirement: required
  order: 310
  fields:
  - field_id: behavior-cases
    value_type: checklist
    required: true
    allowed_values: []
    prompt: List happy, denied, failure, retry, and boundary cases exercised.
  - field_id: test-results
    value_type: command-results
    required: true
    allowed_values: []
    prompt: Record focused and broader test commands and results.
  - field_id: seam-quality
    value_type: string
    required: true
    allowed_values: []
    prompt: State why tests use a durable public seam.
  - field_id: unverified-behavior
    value_type: string-list
    required: true
    allowed_values: []
    prompt: List any behavior not directly verified.
supersedes: []
---

# Test verification source pointer

This generated file contains repository routing metadata only.
It contains no test-verification behavior and is not an editable source owner.

Resolve `test-verification` through the current manifest at
`Ezra144israel/governed-agent-skills:current-skills.json`.
Verify the manifest identity against the accepted release pin.
Load that row's complete canonical root and each reference selected by that root.
If the manifest, root, or selected reference cannot be verified, return `BLOCKED`.

The canonical source owns all test rules and return contributions.
Regenerate this pointer from its canonical routing metadata when that source changes.
